"""
Streamlit user interface for Cellphone Price Range Prediction.
Run: streamlit run app.py
"""
import joblib
import numpy as np
import pandas as pd
import streamlit as st

MODEL_PATH = "models/best_model.joblib"
FEATURE_PATH = "models/feature_names.joblib"

st.set_page_config(page_title="Cellphone Price Predictor", page_icon="📱", layout="centered")
st.title("📱 Cellphone Price Range Predictor")
st.write("Enter the phone specifications to estimate its price category.")

try:
    model = joblib.load(MODEL_PATH)
    features = joblib.load(FEATURE_PATH)
except FileNotFoundError:
    st.error("Trained model not found. First run: python train_model.py")
    st.stop()

# Defaults and sensible input ranges for the standard Kaggle dataset
defaults = {
    "battery_power": (100, 2000, 1000),
    "blue": (0, 1, 1),
    "clock_speed": (0.5, 3.0, 1.5),
    "dual_sim": (0, 1, 1),
    "fc": (0, 19, 5),
    "four_g": (0, 1, 1),
    "int_memory": (2, 64, 32),
    "m_dep": (0.1, 1.0, 0.5),
    "mobile_wt": (80, 200, 150),
    "n_cores": (1, 8, 4),
    "pc": (0, 20, 10),
    "px_height": (0, 1960, 900),
    "px_width": (500, 2000, 1200),
    "ram": (256, 4000, 2000),
    "sc_h": (5, 19, 12),
    "sc_w": (0, 18, 7),
    "talk_time": (2, 20, 10),
    "three_g": (0, 1, 1),
    "touch_screen": (0, 1, 1),
    "wifi": (0, 1, 1),
}

values = {}
with st.form("phone_specs"):
    st.subheader("Phone specifications")
    cols = st.columns(2)
    for i, feature in enumerate(features):
        if feature not in defaults:
            st.warning(f"No input configuration available for feature: {feature}")
            st.stop()
        low, high, default = defaults[feature]
        with cols[i % 2]:
            if feature in {"blue", "dual_sim", "four_g", "three_g", "touch_screen", "wifi"}:
                values[feature] = st.selectbox(
                    feature.replace("_", " ").title(), [0, 1],
                    index=default, format_func=lambda x: "Yes" if x == 1 else "No"
                )
            elif feature == "clock_speed" or feature == "m_dep":
                values[feature] = st.slider(
                    feature.replace("_", " ").title(),
                    float(low), float(high), float(default), step=0.1
                )
            else:
                values[feature] = st.number_input(
                    feature.replace("_", " ").title(),
                    min_value=int(low), max_value=int(high), value=int(default), step=1
                )
    submitted = st.form_submit_button("Predict price range")

if submitted:
    input_df = pd.DataFrame([[values[f] for f in features]], columns=features)
    prediction = int(model.predict(input_df)[0])
    labels = {
        0: "Low Cost",
        1: "Medium Cost",
        2: "High Cost",
        3: "Very High Cost"
    }
    st.success(f"Predicted category: {labels.get(prediction, str(prediction))}")
    st.metric("Predicted price range class", prediction)
    st.caption("This is a category prediction, not an exact selling price.")
