# Cellphone Price Range Prediction

## Objective
Predict one of four mobile price categories (0, 1, 2, 3) from phone hardware specifications using supervised machine learning.

## Dataset
Download the **Mobile Price Classification** dataset from Kaggle and place its `train.csv` file in this project folder. The CSV must contain the 20 specification columns and target column `price_range`.

## Setup
```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

## Train and evaluate
```bash
python train_model.py
```
This creates EDA plots, `model_comparison.csv`, and the trained model under `models/`.

## Run the web app
```bash
streamlit run app.py
```

## Target classes
- 0: Low Cost
- 1: Medium Cost
- 2: High Cost
- 3: Very High Cost

The model predicts a category only. It does not estimate an exact market price. Performance depends on the dataset and train/test split.
